﻿// namespace _02_09_25;
// public class Rules
// {
//     //Valid Option For Async 
//     public async Task DoWorkAsync() { }
//     public async Task<int> GetNumberAsync() { }
//     public async void Button_Click(object sender, EventArgs e) { }

//     //Invalid Option For Async
//     public async int GetNumberAsync() {  }
//     public async string GetNameAsync() { }

//     //Valid Option For Await
//     public async Task DoSomething()
//     {
//         await Task.Delay(1000);
//     }

// }
