﻿namespace _02_09_25;

public class PartialClassTest
{
    private int rollno;
    private string name;

    public PartialClassTest(int rollno, string name)
    {
        this.rollno = rollno;
        this.name = name;
    }

}
