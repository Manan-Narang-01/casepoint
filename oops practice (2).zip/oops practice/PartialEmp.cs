﻿namespace _02_09_25;

public class PartialEmp
{
    public void display(){
        Console.WriteLine("Roll No: " + rollno + " Name: " + name);
    }
}
